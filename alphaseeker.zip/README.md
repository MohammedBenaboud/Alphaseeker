# AlphaSeeker: Quantitative Crypto Intelligence System

AlphaSeeker is a high-performance, modular React application designed to simulate a sophisticated crypto trading bot architecture. It processes market data in real-time, classifies market states using AI, and simulates execution logic under strict risk governance rules.

## System Architecture

The application is divided into three distinct processing modules:

### 1. Ingestion & Scoring (Module 1)
*   **Responsibility:** Collects raw market data, normalizes it, and applies a quantitative scoring algorithm.
*   **Key Metrics:** Volume spikes, Liquidity depth, Volatility Index (VI), Momentum Score (0-100).
*   **Tech:** Real-time mock data stream, Recharts visualization.

### 2. Decision Intelligence (Module 2)
*   **Responsibility:** Interprets scored data to classify the "State of the Market" for each asset.
*   **States:** Dormant, Accumulation, Momentum, Overextended, Unstable.
*   **Tech:** Stateless decision engine, Signal Confidence scoring.

### 3. Execution & Risk Governor (Module 3)
*   **Responsibility:** Converts high-confidence signals into simulated market actions while enforcing capital preservation.
*   **Features:**
    *   **Risk Governor:** Checks for portfolio saturation, cooldowns, and extreme volatility.
    *   **Execution Engine:** Manages Entry/Exit lifecycles.
    *   **Volatility Sizing:** Dynamically adjusts position size based on asset risk.

## Tech Stack

*   **Frontend:** React 19, Tailwind CSS
*   **AI Integration:** Google Gemini API (`@google/genai`) for qualitative analysis.
*   **Visualization:** Recharts, Lucide React icons.
*   **Architecture:** Event-driven, Component-based.

## Setup & Running

This project is built using ES Modules directly in the browser (via `importmap`). No complex bundler setup is required to run the development version.

### Prerequisites

1.  **Google Gemini API Key:** You need a valid API key from [Google AI Studio](https://aistudio.google.com/).

### Instructions

1.  **Environment Variable:**
    Since this is a client-side demo, the API key is accessed via `process.env.API_KEY`. In a local environment using a simple server, you may need to manually inject this or hardcode it for testing (though not recommended for production).
    
    *Note: The application expects `process.env.API_KEY` to be available globally.*

2.  **Install Dependencies (Optional for IntelliSense):**
    ```bash
    npm install
    ```

3.  **Run the Application:**
    You can serve the directory using any static file server.
    ```bash
    npx serve .
    ```
    Open your browser to `http://localhost:3000`.

## Disclaimer

This application is a **simulation** for educational and architectural demonstration purposes. 
*   It uses mock market data.
*   It does **not** execute real financial transactions.
*   It does **not** constitute financial advice.
